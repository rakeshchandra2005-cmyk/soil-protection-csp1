SOILGUARD — SOIL PROTECTION CSP WEBSITE

FILES
- index.html: website content and sections
- style.css: layout, colors, responsive/mobile design
- script.js: mobile navigation and demo feedback form

HOW TO OPEN
1. Extract the ZIP file.
2. Open the soil_protection_csp folder.
3. Double-click index.html. It opens in your browser.
4. For editing, open the folder in Visual Studio Code.

CUSTOMIZE BEFORE SUBMISSION
- In index.html, replace “Add your details here” with your name, college, department, and guide details.
- Update the project details to match your actual CSP work.
- Add real fieldwork photographs and verified project references if your college requires them.
- The feedback form is frontend-only and does not send/store data on a server.

PUBLISH FREE USING GITHUB PAGES
1. Sign in at https://github.com and create a new public repository, e.g. soil-protection-csp.
2. On the repository page, choose Add file > Upload files.
3. Upload index.html, style.css, and script.js (README.txt is optional).
   Important: upload the files themselves to the repository root, not only the ZIP.
4. Click Commit changes.
5. Open Settings > Pages.
6. Under “Build and deployment”, choose “Deploy from a branch”.
7. Select branch “main” and folder “/(root)”, then click Save.
8. Wait a few minutes and refresh the Pages screen. Open the published URL shown there.

NOTE
This project uses no database. The form only demonstrates a frontend interaction. A database or form service is needed to collect feedback from visitors.
