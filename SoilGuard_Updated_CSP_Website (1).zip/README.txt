SOILGUARD — UPDATED SOIL PROTECTION CSP WEBSITE

FILES
- index.html: website content, photo gallery, quiz, references, conclusion, and feedback form
- style.css: responsive layout and styling
- script.js: mobile navigation, quiz scoring, and optional Formspree submission

PUBLISH / UPDATE ON GITHUB PAGES
1. Open your repository: https://github.com/rakeshchandra2005-cmyk/soil-protection-csp1
2. Open the repository's main branch.
3. Choose Add file > Upload files.
4. Upload index.html, style.css, and script.js, replacing the existing files.
5. Commit the changes to the main branch.
6. Wait a few minutes, then refresh https://rakeshchandra2005-cmyk.github.io/soil-protection-csp1/

IMPORTANT: WORKING FEEDBACK FORM
The form is in safe demo mode until you configure a Formspree endpoint.
1. Visit https://formspree.io/ and create a form.
2. Copy your form endpoint, which looks like https://formspree.io/f/xxxxxxxx.
3. In index.html, find: data-formspree-endpoint=""
4. Put your actual endpoint inside the quotes, for example data-formspree-endpoint="https://formspree.io/f/YOUR_ID".
5. Commit the updated index.html and test a submission. Do not use the example YOUR_ID; use your own endpoint.
6. Check Formspree's dashboard/email confirmation to verify the message arrived.

Without a real endpoint, the page explicitly tells visitors that the feedback was not sent or saved. GitHub Pages does not store submissions by itself.

CONTENT NOTES
- The 95% food statistic links to FAO background information. Review the FAO source and context before including the statistic in a formal report.
- Images are loaded from Unsplash image URLs and require an internet connection. Check individual image credits/terms if your college requires attribution.
- The community activity and student/college information should be replaced with your real details and actual activities. Do not invent fieldwork results.
- References include FAO, UNCCD, and UNEP websites.
