const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.textContent = isOpen ? '✕' : '☰';
  });

  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.textContent = '☰';
    });
  });
}

// Feedback form: only sends data after the owner adds a real Formspree endpoint.
const feedbackForm = document.getElementById('feedbackForm');
if (feedbackForm) {
  feedbackForm.addEventListener('submit', async event => {
    event.preventDefault();
    const name = document.getElementById('name').value.trim();
    const message = document.getElementById('formMessage');
    const endpoint = feedbackForm.dataset.formspreeEndpoint.trim();

    if (!endpoint) {
      message.textContent = `Thanks, ${name}. This is demo mode: nothing was sent or saved. To collect feedback, set up Formspree and add your endpoint in index.html.`;
      return;
    }

    if (!/^https:\/\/formspree\.io\/f\/[A-Za-z0-9]+$/.test(endpoint)) {
      message.textContent = 'The form endpoint does not look valid. Please check your Formspree URL in index.html.';
      return;
    }

    const submitButton = feedbackForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = 'Sending…';
    message.textContent = '';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        body: new FormData(feedbackForm),
        headers: { Accept: 'application/json' }
      });
      if (response.ok) {
        message.textContent = 'Thank you! Your feedback was submitted successfully.';
        feedbackForm.reset();
      } else {
        message.textContent = 'Sorry, your feedback could not be submitted. Check your Formspree setup and try again.';
      }
    } catch (error) {
      message.textContent = 'Could not connect to the feedback service. Please check your internet connection and try again.';
    } finally {
      submitButton.disabled = false;
      submitButton.innerHTML = 'Submit feedback <span>→</span>';
    }
  });
}

// Five-question soil protection quiz.
const soilQuiz = document.getElementById('soilQuiz');
if (soilQuiz) {
  const answers = { q1: 'b', q2: 'a', q3: 'c', q4: 'a', q5: 'b' };
  const result = document.getElementById('quizResult');

  soilQuiz.addEventListener('submit', event => {
    event.preventDefault();
    let score = 0;
    for (const [question, answer] of Object.entries(answers)) {
      const selected = soilQuiz.querySelector(`input[name="${question}"]:checked`);
      if (selected && selected.value === answer) score++;
    }
    result.textContent = `Your score: ${score}/5. ${score === 5 ? 'Excellent! You know how to protect soil.' : score >= 3 ? 'Good work! Review the tips and try again.' : 'Keep learning—review the soil-protection tips and try again.'}`;
  });

  soilQuiz.addEventListener('reset', () => {
    result.textContent = '';
  });
}
