# SoilGuard — Soil Protection CSP Website

A responsive, single-file HTML/CSS/JavaScript website for a Soil Protection Community Service Project.

## Included features
- Nature-inspired green and cream design
- Responsive mobile navigation
- Soil degradation and conservation sections
- Conservation-method cards with photographs
- Community awareness action plan
- Interactive 5-question quiz with scoring and restart
- Feedback form using the project's Formspree endpoint
- References, conclusion, accessibility basics, and back-to-top control

## Publish on GitHub Pages
1. Open https://github.com/rakeshchandra2005-cmyk/soil-protection-csp1
2. Open `index.html` (make a backup first if you want to preserve your previous version).
3. Click the pencil / Edit this file icon. If GitHub says you must be on a branch, switch to the repository's default branch (usually `main`) first.
4. Replace the file contents with the supplied `index.html` from this package, or upload the file using **Add file → Upload files**.
5. Click **Commit changes** and commit to the publishing branch.
6. Open **Settings → Pages** and confirm the source is the correct branch and folder (usually `main` and `/(root)`).
7. Wait for the Pages deployment to finish, then visit:
   https://rakeshchandra2005-cmyk.github.io/soil-protection-csp1/
8. Hard-refresh with Ctrl+F5 if an old version is cached.

## Feedback form
The HTML is configured to use `https://formspree.io/f/xdeazlel`, the Formspree endpoint supplied by the site owner in an earlier setup. Submit a test response after publishing. If it does not arrive, sign in to Formspree and verify the form endpoint, allowed settings, and email confirmation.

## Before CSP submission
- Replace/add your college, department, student/team details, and faculty guide where required.
- Use your own genuine activity photographs if you conduct a community activity. Do not claim activities occurred unless they did.
- The photos in this starter use remote Unsplash image URLs, so an internet connection is needed to load them. For a stable project submission, download appropriately licensed images and keep them in an `assets/` folder, then update each image path.
- Verify reference links and test all navigation, quiz buttons, mobile layout, and form submissions.
- This is a static site. Quiz scores are not stored on a server, and the feedback form is the only feature that sends data externally.
